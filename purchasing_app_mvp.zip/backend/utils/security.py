
from datetime import datetime, timedelta
from jose import jwt, JWTError
from passlib.hash import bcrypt
from fastapi import HTTPException, status

def hash_password(pw: str) -> str:
    return bcrypt.hash(pw)

def verify_password(pw: str, hashed: str) -> bool:
    return bcrypt.verify(pw, hashed)

def create_jwt(sub: str, secret: str, expire_minutes: int):
    to_encode = {"sub": sub, "exp": datetime.utcnow() + timedelta(minutes=expire_minutes)}
    return jwt.encode(to_encode, secret, algorithm="HS256")

def decode_jwt(token: str, secret: str) -> str:
    try:
        payload = jwt.decode(token, secret, algorithms=["HS256"])
        return payload.get("sub")
    except JWTError:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token")
