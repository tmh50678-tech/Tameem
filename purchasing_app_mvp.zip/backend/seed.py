
from .db import Base, engine, SessionLocal
from .models.core import User, Vendor, Item
from .utils.security import hash_password

def seed():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    users = [
        ("admin@example.com","Admin","admin123","admin"),
        ("manager@example.com","Manager","manager123","manager"),
        ("buyer@example.com","Buyer","buyer123","buyer"),
        ("requester@example.com","Requester","requester123","requester"),
        ("accountant@example.com","Accountant","accountant123","accountant"),
        ("auditor@example.com","Auditor","auditor123","auditor"),
    ]
    for email,name,pw,role in users:
        if not db.query(User).filter(User.email==email).first():
            db.add(User(email=email, name=name, password_hash=hash_password(pw), role=role))
    vendors = [("ACME Supplies","acme@ex.com","+966500000001",4.4,5),
               ("Desert Traders","desert@ex.com","+966500000002",4.0,7)]
    for name,email,phone,rating,lead in vendors:
        from .models.core import Vendor
        if not db.query(Vendor).filter(Vendor.name==name).first():
            db.add(Vendor(name=name, contact_email=email, phone=phone, rating=rating, lead_time_days=lead))
    items = [("RICE-5KG","Rice 5kg","Food","bag",28.5,None),
             ("SOAP-1L","Liquid Soap 1L","Cleaning","bottle",12.0,None),
             ("TOWEL-WHT","White Towel","Linen","ea",8.5,None)]
    from .models.core import Item
    for sku,name,cat,uom,price,pv in items:
        if not db.query(Item).filter(Item.sku==sku).first():
            db.add(Item(sku=sku, name=name, category=cat, uom=uom, last_market_price=price, preferred_vendor_id=pv))
    db.commit()
    db.close()

if __name__ == "__main__":
    seed()
