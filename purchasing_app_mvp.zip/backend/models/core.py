
from sqlalchemy import Column, Integer, String, DateTime, Enum, ForeignKey, Float, Boolean, Text, Table
from sqlalchemy.orm import relationship, Mapped, mapped_column
from datetime import datetime
from ..db import Base
import enum

class RoleEnum(enum.Enum):
    admin="admin"
    manager="manager"
    buyer="buyer"
    requester="requester"
    accountant="accountant"
    auditor="auditor"

class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    email: Mapped[str] = mapped_column(String, unique=True, index=True, nullable=False)
    name: Mapped[str] = mapped_column(String, default="")
    password_hash: Mapped[str] = mapped_column(String, nullable=False)
    role: Mapped[str] = mapped_column(Enum(RoleEnum), default=RoleEnum.requester)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class Vendor(Base):
    __tablename__ = "vendors"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String, unique=True, index=True)
    contact_email: Mapped[str] = mapped_column(String, default="")
    phone: Mapped[str] = mapped_column(String, default="")
    rating: Mapped[float] = mapped_column(Float, default=3.0)
    lead_time_days: Mapped[int] = mapped_column(Integer, default=7)
    active: Mapped[bool] = mapped_column(Boolean, default=True)

class Item(Base):
    __tablename__ = "items"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    sku: Mapped[str] = mapped_column(String, unique=True, index=True)
    name: Mapped[str] = mapped_column(String, index=True)
    category: Mapped[str] = mapped_column(String, index=True)
    uom: Mapped[str] = mapped_column(String, default="ea")
    last_market_price: Mapped[float] = mapped_column(Float, default=0.0)
    preferred_vendor_id: Mapped[int|None] = mapped_column(Integer, ForeignKey("vendors.id"), nullable=True)
    preferred_vendor = relationship("Vendor")

class PriceList(Base):
    __tablename__ = "price_lists"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    item_id: Mapped[int] = mapped_column(Integer, ForeignKey("items.id"))
    vendor_id: Mapped[int] = mapped_column(Integer, ForeignKey("vendors.id"))
    price: Mapped[float] = mapped_column(Float, default=0.0)
    currency: Mapped[str] = mapped_column(String, default="SAR")
    valid_from: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    valid_to: Mapped[datetime|None] = mapped_column(DateTime, nullable=True)

class PurchaseRequestStatus(enum.Enum):
    draft="draft"
    submitted="submitted"
    approved="approved"
    rejected="rejected"
    converted="converted"

class PurchaseRequest(Base):
    __tablename__ = "purchase_requests"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    requester_id: Mapped[int] = mapped_column(Integer, ForeignKey("users.id"))
    title: Mapped[str] = mapped_column(String)
    justification: Mapped[str] = mapped_column(Text, default="")
    status: Mapped[str] = mapped_column(Enum(PurchaseRequestStatus), default=PurchaseRequestStatus.draft)
    total_amount: Mapped[float] = mapped_column(Float, default=0.0)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class PRLine(Base):
    __tablename__ = "pr_lines"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    pr_id: Mapped[int] = mapped_column(Integer, ForeignKey("purchase_requests.id"))
    item_id: Mapped[int] = mapped_column(Integer, ForeignKey("items.id"))
    qty: Mapped[float] = mapped_column(Float, default=1.0)
    est_price: Mapped[float] = mapped_column(Float, default=0.0)

class RFQ(Base):
    __tablename__ = "rfqs"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    pr_id: Mapped[int] = mapped_column(Integer, ForeignKey("purchase_requests.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    sent_to: Mapped[str] = mapped_column(Text, default="")  # csv vendor ids

class Quotation(Base):
    __tablename__ = "quotations"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    rfq_id: Mapped[int] = mapped_column(Integer, ForeignKey("rfqs.id"))
    vendor_id: Mapped[int] = mapped_column(Integer, ForeignKey("vendors.id"))
    item_id: Mapped[int] = mapped_column(Integer, ForeignKey("items.id"))
    unit_price: Mapped[float] = mapped_column(Float, default=0.0)
    lead_time_days: Mapped[int] = mapped_column(Integer, default=7)

class POStatus(enum.Enum):
    draft="draft"
    sent="sent"
    acknowledged="acknowledged"
    partially_received="partially_received"
    received="received"
    invoiced="invoiced"
    closed="closed"

class PurchaseOrder(Base):
    __tablename__ = "purchase_orders"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    pr_id: Mapped[int] = mapped_column(Integer, ForeignKey("purchase_requests.id"))
    vendor_id: Mapped[int] = mapped_column(Integer, ForeignKey("vendors.id"))
    status: Mapped[str] = mapped_column(Enum(POStatus), default=POStatus.draft)
    total_amount: Mapped[float] = mapped_column(Float, default=0.0)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class POLine(Base):
    __tablename__ = "po_lines"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    po_id: Mapped[int] = mapped_column(Integer, ForeignKey("purchase_orders.id"))
    item_id: Mapped[int] = mapped_column(Integer, ForeignKey("items.id"))
    qty: Mapped[float] = mapped_column(Float, default=1.0)
    unit_price: Mapped[float] = mapped_column(Float, default=0.0)

class GRN(Base):
    __tablename__ = "grns"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    po_id: Mapped[int] = mapped_column(Integer, ForeignKey("purchase_orders.id"))
    received_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    notes: Mapped[str] = mapped_column(Text, default="")

class GRNLine(Base):
    __tablename__ = "grn_lines"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    grn_id: Mapped[int] = mapped_column(Integer, ForeignKey("grns.id"))
    item_id: Mapped[int] = mapped_column(Integer, ForeignKey("items.id"))
    qty_received: Mapped[float] = mapped_column(Float, default=0.0)
    quality_ok: Mapped[bool] = mapped_column(Boolean, default=True)

class Invoice(Base):
    __tablename__ = "invoices"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    po_id: Mapped[int] = mapped_column(Integer, ForeignKey("purchase_orders.id"))
    invoice_no: Mapped[str] = mapped_column(String, index=True)
    amount: Mapped[float] = mapped_column(Float, default=0.0)
    vat_amount: Mapped[float] = mapped_column(Float, default=0.0)
    currency: Mapped[str] = mapped_column(String, default="SAR")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class Payment(Base):
    __tablename__ = "payments"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    invoice_id: Mapped[int] = mapped_column(Integer, ForeignKey("invoices.id"))
    amount: Mapped[float] = mapped_column(Float, default=0.0)
    paid_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    method: Mapped[str] = mapped_column(String, default="bank_transfer")

class AuditLog(Base):
    __tablename__ = "audit_log"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    actor_id: Mapped[int] = mapped_column(Integer, ForeignKey("users.id"))
    action: Mapped[str] = mapped_column(String)
    entity: Mapped[str] = mapped_column(String)
    entity_id: Mapped[int] = mapped_column(Integer)
    timestamp: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    details: Mapped[str] = mapped_column(Text, default="")
