
from pydantic import BaseModel, EmailStr
from typing import Optional, Literal

Role = Literal["admin","manager","buyer","requester","accountant","auditor"]

class UserCreate(BaseModel):
    email: EmailStr
    name: str
    password: str
    role: Role = "requester"

class UserOut(BaseModel):
    id: int
    email: EmailStr
    name: str
    role: Role
    class Config:
        from_attributes = True

class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"

class LoginIn(BaseModel):
    email: EmailStr
    password: str
