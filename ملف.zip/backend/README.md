
# Purchasing App MVP (FastAPI + SQLite)

This is a fully working **Purchasing Workflow** backend you can run locally right away.
It includes: vendors, items, catalogs, RFQs, quotations, purchase requests, approvals,
purchase orders, goods receipts, invoices, payments, audit log, and role-based access.

## Quick start

1) Create venv & install deps
```
cd backend
python -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```
2) Run
```
uvicorn main:app --reload
```
3) Open docs:
- http://127.0.0.1:8000/docs
- http://127.0.0.1:8000/redoc

## Users & Roles (seeded)
- admin@example.com / admin123  -> admin
- manager@example.com / manager123 -> manager
- buyer@example.com / buyer123 -> buyer
- requester@example.com / requester123 -> requester
- accountant@example.com / accountant123 -> accountant
- auditor@example.com / auditor123 -> auditor

## Key Concepts

- **PurchaseRequest (PR):** raised by requester; auto routes for approval based on amount and category rules.
- **RFQ / Quotation:** buyer sends RFQ to vendors, records quotations; system recommends best quote (price + lead time + vendor score).
- **PO:** generated from approved PR + chosen quotation. Status flow: DRAFT -> SENT -> ACK -> PARTIALLY_RECEIVED -> RECEIVED -> INVOICED -> CLOSED.
- **GRN:** goods receipt note; supports partial receipts and quality check.
- **Invoice:** matched 3-way (PO, GRN, Invoice). Flags duplicates and price over market.
- **Payment:** records payment and links to invoice.
- **AuditLog:** immutable log of all actions.
- **AI hooks:** stubs to: price-check vs market, duplicate invoice detection, OCR parsing endpoint.

## Tech
- FastAPI, SQLAlchemy 2.0, Pydantic v2, Passlib JWT auth, SQLite (switchable to Postgres easily)

## Env
```
DATABASE_URL=sqlite:///./app.db
JWT_SECRET=change-me
JWT_EXPIRE_MINUTES=1440
```
