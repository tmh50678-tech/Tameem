
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .db import Base, engine
from .seed import seed
from .routers import auth, master_data, purchasing, ai

Base.metadata.create_all(bind=engine)
seed()

app = FastAPI(title="Purchasing App MVP", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=['*'],
    allow_credentials=True,
    allow_methods=['*'],
    allow_headers=['*'],
)

app.include_router(auth.router)
app.include_router(master_data.router)
app.include_router(purchasing.router)
app.include_router(ai.router)

@app.get("/", tags=["health"])
def health():
    return {"ok": True}
