
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from ..db import get_db
from ..models.core import Vendor, Item, PriceList
from .auth import get_current_user

router = APIRouter(prefix="/master", tags=["master-data"])

@router.get("/vendors")
def list_vendors(db: Session = Depends(get_db), user=Depends(get_current_user)):
    return db.query(Vendor).all()

@router.post("/vendors")
def create_vendor(v: dict, db: Session = Depends(get_db), user=Depends(get_current_user)):
    vendor = Vendor(**v)
    db.add(vendor); db.commit(); db.refresh(vendor)
    return vendor

@router.get("/items")
def list_items(db: Session = Depends(get_db), user=Depends(get_current_user)):
    return db.query(Item).all()

@router.post("/items")
def create_item(i: dict, db: Session = Depends(get_db), user=Depends(get_current_user)):
    item = Item(**i)
    db.add(item); db.commit(); db.refresh(item)
    return item
