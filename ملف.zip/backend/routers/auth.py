
from fastapi import APIRouter, Depends, HTTPException, status, Header
from sqlalchemy.orm import Session
from ..db import get_db, Base, engine
from ..models.core import User, RoleEnum
from ..utils.security import create_jwt, hash_password, verify_password, decode_jwt
from ..settings import settings
from ..schemas.user import UserCreate, UserOut, TokenOut, LoginIn

router = APIRouter(prefix="/auth", tags=["auth"])

@router.post("/register", response_model=UserOut)
def register(payload: UserCreate, db: Session = Depends(get_db)):
    if db.query(User).filter(User.email==payload.email).first():
        raise HTTPException(400, "Email already registered")
    user = User(email=payload.email, name=payload.name, password_hash=hash_password(payload.password), role=RoleEnum(payload.role))
    db.add(user); db.commit(); db.refresh(user)
    return user

@router.post("/login", response_model=TokenOut)
def login(payload: LoginIn, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email==payload.email).first()
    if not user or not verify_password(payload.password, user.password_hash):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")
    token = create_jwt(str(user.id), settings.JWT_SECRET, settings.JWT_EXPIRE_MINUTES)
    return {"access_token": token}

def get_current_user(authorization: str = Header(...), db: Session = Depends(get_db)):
    if not authorization.startswith("Bearer "):
        raise HTTPException(401, "Missing bearer token")
    token = authorization.split(" ",1)[1]
    user_id = decode_jwt(token, settings.JWT_SECRET)
    user = db.get(User, int(user_id))
    if not user:
        raise HTTPException(401, "User not found")
    return user
