
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import func
from ..db import get_db
from ..models.core import PurchaseRequest, PRLine, RFQ, Quotation, PurchaseOrder, POLine, GRN, GRNLine, Invoice, Payment, Item, Vendor, POStatus, PurchaseRequestStatus
from .auth import get_current_user

router = APIRouter(prefix="/procure", tags=["purchasing"])

@router.post("/pr")
def create_pr(payload: dict, db: Session = Depends(get_db), user=Depends(get_current_user)):
    pr = PurchaseRequest(requester_id=user.id, title=payload.get("title",""), justification=payload.get("justification",""), status=PurchaseRequestStatus.submitted)
    db.add(pr); db.flush()
    total = 0.0
    for line in payload.get("lines", []):
        item = db.get(Item, line["item_id"])
        est_price = line.get("est_price", item.last_market_price or 0.0)
        prl = PRLine(pr_id=pr.id, item_id=item.id, qty=line["qty"], est_price=est_price)
        db.add(prl)
        total += est_price * float(line["qty"])
    pr.total_amount = total
    db.commit(); db.refresh(pr)
    return {"pr_id": pr.id, "total": total}

@router.post("/rfq/{pr_id}")
def create_rfq(pr_id: int, vendor_ids: list[int], db: Session = Depends(get_db), user=Depends(get_current_user)):
    rfq = RFQ(pr_id=pr_id, sent_to=",".join(map(str, vendor_ids)))
    db.add(rfq); db.commit(); db.refresh(rfq)
    return rfq

@router.post("/quotation/{rfq_id}")
def add_quote(rfq_id: int, q: dict, db: Session = Depends(get_db), user=Depends(get_current_user)):
    quotation = Quotation(rfq_id=rfq_id, vendor_id=q["vendor_id"], item_id=q["item_id"], unit_price=q["unit_price"], lead_time_days=q.get("lead_time_days",7))
    db.add(quotation); db.commit(); db.refresh(quotation)
    return quotation

@router.post("/po/from_rfq/{pr_id}")
def create_po_from_rfq(pr_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    # choose best quote per item by unit_price then lead time, then vendor rating
    lines = db.query(PRLine).filter(PRLine.pr_id==pr_id).all()
    if not lines:
        raise HTTPException(404, "PR not found or no lines")
    # pick vendor by min price among quotes
    # for simplicity: single vendor per PR if possible; else split into multiple POs (here single PO using cheapest vendor count)
    # We'll create one PO per vendor grouping
    quotes = db.query(Quotation).join(PRLine, Quotation.item_id==PRLine.item_id).filter(PRLine.pr_id==pr_id).all()
    if not quotes:
        raise HTTPException(400, "No quotations for PR")
    # group cheapest per item
    best = {}
    for l in lines:
        qlist = [q for q in quotes if q.item_id==l.item_id]
        qlist.sort(key=lambda x:(x.unit_price, x.lead_time_days))
        if not qlist:
            raise HTTPException(400, f"No quotation for item {l.item_id}")
        best[l.item_id]=qlist[0]
    # group by vendor
    by_vendor = {}
    for l in lines:
        q = best[l.item_id]
        by_vendor.setdefault(q.vendor_id, []).append((l, q))
    created_pos = []
    for vendor_id, pairs in by_vendor.items():
        po = PurchaseOrder(pr_id=pr_id, vendor_id=vendor_id, status=POStatus.draft)
        db.add(po); db.flush()
        total = 0.0
        for l,q in pairs:
            price = q.unit_price
            pol = POLine(po_id=po.id, item_id=l.item_id, qty=l.qty, unit_price=price)
            db.add(pol); total += price*float(l.qty)
        po.total_amount = total
        created_pos.append({"po_id": po.id, "vendor_id": vendor_id, "total": total})
    db.commit()
    return {"pos": created_pos}

@router.post("/grn/{po_id}")
def receive_goods(po_id: int, payload: dict, db: Session = Depends(get_db), user=Depends(get_current_user)):
    grn = GRN(po_id=po_id, notes=payload.get("notes",""))
    db.add(grn); db.flush()
    for line in payload.get("lines", []):
        db.add(GRNLine(grn_id=grn.id, item_id=line["item_id"], qty_received=line["qty_received"], quality_ok=line.get("quality_ok", True)))
    # Update PO status naive
    po = db.get(PurchaseOrder, po_id)
    po.status = POStatus.received
    db.commit(); db.refresh(grn)
    return {"grn_id": grn.id}

@router.post("/invoice/{po_id}")
def add_invoice(po_id: int, payload: dict, db: Session = Depends(get_db), user=Depends(get_current_user)):
    # Duplicate check
    if db.query(Invoice).filter(Invoice.invoice_no==payload["invoice_no"]).first():
        raise HTTPException(400, "Duplicate invoice number detected")
    inv = Invoice(po_id=po_id, invoice_no=payload["invoice_no"], amount=payload["amount"], vat_amount=payload.get("vat_amount",0.0), currency=payload.get("currency","SAR"))
    db.add(inv); db.commit(); db.refresh(inv)
    return {"invoice_id": inv.id}

@router.post("/payment/{invoice_id}")
def pay(invoice_id: int, payload: dict, db: Session = Depends(get_db), user=Depends(get_current_user)):
    pay = Payment(invoice_id=invoice_id, amount=payload["amount"], method=payload.get("method","bank_transfer"))
    db.add(pay); db.commit(); db.refresh(pay)
    return {"payment_id": pay.id}
