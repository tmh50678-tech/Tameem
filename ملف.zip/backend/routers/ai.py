
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from sqlalchemy.orm import Session
from ..db import get_db
from ..models.core import Item
from .auth import get_current_user

router = APIRouter(prefix="/ai", tags=["ai-hooks"])

@router.get("/price-check/{item_id}")
def price_check(item_id: int, offered_price: float, db: Session = Depends(get_db), user=Depends(get_current_user)):
    item = db.get(Item, item_id)
    if not item:
        raise HTTPException(404, "Item not found")
    market = item.last_market_price or 0.0
    flag = offered_price > market * 1.15 if market>0 else False
    return {"item_id": item_id, "offered_price": offered_price, "market_price": market, "over_market_flag": flag}

@router.post("/ocr-invoice")
def ocr_invoice(file: UploadFile = File(...), user=Depends(get_current_user)):
    # Stub - just returns a fake parsed payload
    name = file.filename
    return {"parsed": {"invoice_no": "INV-FAKE-001", "amount": 1234.56, "vendor": "ACME"}, "note": "OCR stub - integrate Tesseract or external OCR here"}
