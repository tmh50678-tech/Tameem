
import { useState } from 'react'
import { apiFetch } from '../utils/api'
import Nav from '../components/Nav'

export default function Payment(){
  const [invoiceId,setInvoiceId]=useState(1)
  const [amount,setAmount]=useState(100)
  const [method,setMethod]=useState('bank_transfer')
  const [msg,setMsg]=useState('')

  async function pay(){
    try{
      const payload = { amount: parseFloat(amount), method }
      const res = await apiFetch(`/procure/payment/${invoiceId}`, { method:'POST', body: JSON.stringify(payload)})
      setMsg('تم تسجيل دفع #: '+res.payment_id)
    }catch(e){ setMsg('⚠️ '+e.message) }
  }

  return (<div className="container">
    <h1>المدفوعات</h1>
    <Nav/>
    <div className="card">
      <label>Invoice ID</label><input type="number" value={invoiceId} onChange={e=>setInvoiceId(parseInt(e.target.value))}/>
      <label>المبلغ</label><input type="number" step="0.01" value={amount} onChange={e=>setAmount(e.target.value)}/>
      <label>طريقة الدفع</label><input value={method} onChange={e=>setMethod(e.target.value)}/>
      <button onClick={pay}>تسجيل دفع</button>
      <p>{msg}</p>
    </div>
  </div>)
}
