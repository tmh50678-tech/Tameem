
import { useState } from 'react'
import { apiFetch } from '../utils/api'
import Nav from '../components/Nav'

export default function Invoice(){
  const [poId,setPoId]=useState(1)
  const [invoiceNo,setInvoiceNo]=useState('INV-1001')
  const [amount,setAmount]=useState(100)
  const [vat,setVat]=useState(15)
  const [currency,setCurrency]=useState('SAR')
  const [msg,setMsg]=useState('')

  async function createInvoice(){
    try{
      const payload = { invoice_no: invoiceNo, amount: parseFloat(amount), vat_amount: parseFloat(vat), currency }
      const res = await apiFetch(`/procure/invoice/${poId}`, { method:'POST', body: JSON.stringify(payload)})
      setMsg('تم إنشاء فاتورة #: '+res.invoice_id)
    }catch(e){ setMsg('⚠️ '+e.message) }
  }

  return (<div className="container">
    <h1>الفواتير</h1>
    <Nav/>
    <div className="card">
      <label>PO ID</label><input type="number" value={poId} onChange={e=>setPoId(parseInt(e.target.value))}/>
      <label>رقم الفاتورة</label><input value={invoiceNo} onChange={e=>setInvoiceNo(e.target.value)}/>
      <label>المبلغ</label><input type="number" step="0.01" value={amount} onChange={e=>setAmount(e.target.value)}/>
      <label>ضريبة VAT</label><input type="number" step="0.01" value={vat} onChange={e=>setVat(e.target.value)}/>
      <label>العملة</label><input value={currency} onChange={e=>setCurrency(e.target.value)}/>
      <button onClick={createInvoice}>إنشاء فاتورة</button>
      <p>{msg}</p>
    </div>
  </div>)
}
